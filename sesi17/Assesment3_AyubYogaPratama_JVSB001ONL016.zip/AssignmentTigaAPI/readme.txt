Nama					: Ayub Yoga Pratama
Kode Peserta			: JVSB001ONL016
Link Github				: github.com/ayubyoga
Panduan Penggunaan Aplikasi   :

- landing page masih belum berhasil, saya stuck dalam pengerjaannya. jika masih ada kesempatan akan saya coba perbaiki.

langkah-langkah :
1. Eclipse / VS Code
- Klik kanan pada project , Run As Maven Clean, Install
- Pada menu Boot Dashboard, klik boot, klik kanan pada nama file yang dilakukan proses sebelumnya, klik (re)Start
- Klik Open Web Browser. Sistem akan berjalan pada localhost:8081

2. Postman
Pengujian untuk metode POST, GET, DELETE


Nama         : Ayub Yoga Pratama
Kode Peserta : JVSB001ONL016
Link Github  : github.com/ayubyoga

Panduan :

* Mohon maaf jika masih belum fasih menerapkan konsep OOP, masih ada beberapa hal yang belum saya pahami

Latihan 1 : Latihan One
- input nilai seperti biasa, 3 nilai X,Y,Z
- untuk mencari maksimalnya saya menggunakan konsep Math.max(X,Y)
- average dihitung seperti biasa

Latihan 2 : LatihanTwo
- menggunakan konsep array, input dari user

Latihan 3 : LatihanThree
- Input harga pembelian by user
- Program secara otomatis menentukan diskon yang diterima dan mengeluarkan hasil perhitungan
- Perhitungan diskon berdasarkan kondisi yang diminta

Latihan 4 : LatihanFour
- Input tahun yang akan ditentukan kabisat atau tidak
- Logic Kabisat :
	-- cek apakah nilai tahun habis dibagi 4
	-- Periksa apakah tahun tsb habis dibagi 100. Jika habis dibagi 4, tapi tidak habis dibagi 100
	   maka tahun tersebut adalah tahun kabisat
	-- Periksa apakah tahun tsb habis dibagi 400
	   kalau habis dibagi 100, tapi tidak habis dibagi 400, tahun tsb BUKAN tahun kabisat

Latihan 5 : LatihanFive
- Saya membuat opsi yang ada (table) menjadi case, dan diambil saat pilihan dari user dimasukkan
- User dapat memilih jumlah jenis barang yang akan dibeli
- input kode barang, jumlah barang
- secara otomatis hasil akan keluar
- untuk harga yang ada di bagian hasil, bisa menggunakan formatting, namun saya belum memahami

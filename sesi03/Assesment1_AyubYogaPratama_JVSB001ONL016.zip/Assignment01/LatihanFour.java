public class LatihanFour {
    public static void main(String[] args) {

        // Variables
        int a = 10;
        int b = 8;
        int c = 12;
        int d = 5;

        // Perbandingan
        System.out.println("Tes ke 1 = " + (a > b));
        System.out.println("Tes ke 2 = " + (a < c));
        System.out.println("Tes ke 3 = " + (a >= b));
        System.out.println("Tes ke 4 = " + (d <= b));
        System.out.println("Tes ke 5 = " + (a == a));
        System.out.println("Tes ke 6 = " + (a != b));
        System.out.println("Tes ke 7 = " + (b > a));
        System.out.println("Tes ke 8 = " + (a <= b));
        System.out.println("Tes ke 9 = " + (b == d));
        System.out.println("Tes ke 10 = " + (c != c));

    }
}
